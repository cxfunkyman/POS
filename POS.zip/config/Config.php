<?php
//define('BASE_URL', 'http://localhost/POS/'); // To work with XAMPP
define('BASE_URL', 'http://10.0.0.57/POS/'); // Work with local network
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DBNAME', 'system');
define('CHARSET', 'utf8');
define('TITLE', 'Sales Manager');
define('CURRENCY', '$ ');
define('PRINTER', 'POS-58-Series');
define('HOST_SMTP', 'smtp.gmail.com');
define('USER_SMTP', 'kazcorptm@gmail.com');
define('CODE_SMTP', 'zimralapwkvpvwkz');
define('PORT_SMTP', 465);
?>